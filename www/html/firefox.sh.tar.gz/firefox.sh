#copy the follwing commands in terminal and your password is "redhat"

ssh 192.168.10.254 -X firefox
