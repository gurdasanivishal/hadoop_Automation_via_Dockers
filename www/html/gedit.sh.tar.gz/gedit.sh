ssh -X 192.168.43.109 gedit

